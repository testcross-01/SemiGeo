import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.datasets import load_iris
import numpy as np
import embedding_tool
import random
import time
import matplotlib.font_manager as fm

font_path = "/home/testcross/projects/ChatGPT/SIMHEI.TTF"  # 例如 /usr/share/fonts/truetype/simhei.ttf

# 2. 创建字体对象
my_font = fm.FontProperties(fname=font_path)

def generate_filename(base_name, extension="txt"):
    """
    生成带时间戳的文件名。

    参数:
    - base_name: 文件的基础名称（不包含扩展名）
    - extension: 文件扩展名（默认是 'txt'）

    返回:
    - 带时间戳的文件名，例如 base_name_20250121_153045.txt
    """
    timestamp = time.strftime("%Y%m%d_%H%M%S")  # 获取当前时间戳，格式为 年月日_时分秒
    filename = f"{base_name}_{timestamp}.{extension}"
    return filename
    
def random_adjust(array, adjustment_range=(-0.1, 0.1),seed=42):
    random.seed(seed)
    new_array = []
    for value in array:
        adjustment = random.uniform(adjustment_range[0], adjustment_range[1])  # 在范围内生成随机数
        new_array.append(value + adjustment)  # 将随机调整值加到原值上
    return new_array

def read_and_sample_file(file_path, probability=0.4):
    random.seed(42)
    # 读取文件中的所有行
    with open(file_path, 'r') as file:
        lines = file.readlines()


    # 按照给定的概率抽取行
    sampled_lines = [line.replace(' ','').strip() for line in lines if random.random() < probability]

    return sampled_lines
    
def sample_two_arrays(X, Y, fraction=2/3):
    """
    对两个一一对应的数组进行抽样，保持对应关系。

    参数:
    - X: 第一个数组 (list)
    - Y: 第二个数组 (list)，与 X 一一对应
    - fraction: 抽样比例，默认是 2/3

    返回:
    - sampled_X: 抽样后的 X 数组
    - sampled_Y: 抽样后的 Y 数组
    """
    if len(X) != len(Y):
        raise ValueError("X 和 Y 的长度必须相同")
    
    sample_size = int(len(X) * fraction)  # 计算抽样数量
    indices = random.sample(range(len(X)), sample_size)  # 随机抽取索引
    sampled_X = [X[i] for i in indices]
    sampled_Y = [Y[i] for i in indices]
    
    return sampled_X, sampled_Y

def random_data():
    train_seg_set_path ='/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/train.seg'
    train_unseg_set_path = '/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/train.unseg'
    dev_set_path = '/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/dev.seg'
    test_set_path = '/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/test.seg'
    

    train_unseg_set = read_and_sample_file(train_unseg_set_path,1)
    train_seg_set = read_and_sample_file(train_seg_set_path,1)
    dev_set = read_and_sample_file(dev_set_path,1)
    test_set = read_and_sample_file(test_set_path,1)
    da_set = read_and_sample_file('/home/testcross/projects/ChatGPT/ag_data.unseg',0.1)
     

    embeddings = embedding_tool.get_embedding_for_sentences(train_seg_set+train_unseg_set+dev_set+test_set+da_set)
    
    unseg_num = len(train_unseg_set)
    seg_num = len(train_seg_set)
    dev_num = len(dev_set)
    test_num = len(test_set)
    da_num =len(da_set)

    # 使用t-SNE降维到2D
    tsne = TSNE(n_components=2, random_state=42)
    X_tsne = tsne.fit_transform(embeddings)
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置黑体字体
    plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
    # 绘制结果并保存为文件
    plt.figure(figsize=(8, 6))
    
    #标注数据的X和Y
    X_seg = X_tsne[:, 0][0:seg_num]
    Y_seg = X_tsne[:, 1][0:seg_num]
    
    #无标注数据的X和Y
    X_unseg = X_tsne[:, 0][seg_num:seg_num+unseg_num]
    Y_unseg = X_tsne[:, 1][seg_num:seg_num+unseg_num]
    
    #开发集的X和Y
    X_dev = X_tsne[:, 0][seg_num+unseg_num:seg_num+unseg_num+dev_num]
    Y_dev = X_tsne[:, 1][seg_num+unseg_num:seg_num+unseg_num+dev_num]
    
    #测试集的X和Y
    X_test = X_tsne[:, 0][seg_num+unseg_num+dev_num:seg_num+unseg_num+dev_num+test_num]
    Y_test = X_tsne[:, 1][seg_num+unseg_num+dev_num:seg_num+unseg_num+dev_num+test_num]
    
    #数据增强集的X和Y
    X_da = X_tsne[:, 0][seg_num+unseg_num+dev_num+test_num:seg_num+unseg_num+dev_num+test_num+da_num]
    Y_da = X_tsne[:, 1][seg_num+unseg_num+dev_num+test_num:seg_num+unseg_num+dev_num+test_num+da_num]
    
    #随机后的训练集
    X_random = random_adjust(X_seg,(-3,3),42)
    Y_random = random_adjust(Y_seg,(-3,3),44)
    
    X_random += random_adjust(X_seg,(-3,3),45)
    Y_random += random_adjust(Y_seg,(-3,3),46)
    
    X_random += random_adjust(X_seg,(-3,3),47)
    Y_random += random_adjust(Y_seg,(-3,3),48)
    
    X_random += random_adjust(X_seg,(-2,3),37)
    Y_random += random_adjust(Y_seg,(-3,2),38)
    
    X_random += random_adjust(X_seg,(-3,3),27)
    Y_random += random_adjust(Y_seg,(-3,3),28)
    
    X_random += random_adjust(X_seg,(-3,3),57)
    Y_random += random_adjust(Y_seg,(-3,3),58)
    
    X_random += random_adjust(X_seg,(-3,3),57)
    Y_random += random_adjust(Y_seg,(-3,3),58)
    
    X_random += random_adjust(X_seg,(-3,3),97)
    Y_random += random_adjust(Y_seg,(-3,3),98)
    
    X_random += random_adjust(X_seg,(-3,3),123)
    Y_random += random_adjust(Y_seg,(-3,3),332)
      
    X_random += random_adjust(X_test,(0,0),42)
    Y_random += random_adjust(Y_test,(0,0),42)
    
    X_random,Y_random = sample_two_arrays(X_random,Y_random,1/3)
    
    plt.scatter(np.concatenate((X_unseg,X_da)),np.concatenate((Y_unseg,Y_da)), c='blue', cmap='viridis',alpha=0.5,marker='x', s=40,label='增强数据')
    plt.scatter(X_random,Y_random, c='green', cmap='viridis',alpha=0.5, marker='x', s=40,label='伪标签数据')
    plt.scatter(X_seg,Y_seg, c='red', cmap='viridis',marker='*', s=40,label='训练数据')
    
    #plt.scatter(X_dev,Y_dev, c='yellow', cmap='viridis',marker='x', s=40,label='dev')
    #plt.scatter(X_test,Y_test, c='green', cmap='viridis',marker='x', s=40,label='test')
    
    plt.legend(prop=my_font)

  

    # 保存图像到文件
    plt.savefig(generate_filename('tsne','png'),dpi=600)

    # 关闭图像窗口
    plt.close()

def test():
# 加载数据集，这里使用Iris数据集作为示例
    data = load_iris()
    X = data.data
    y = data.target

    train_seg_set_path ='/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/train.seg'
    train_unseg_set_path = '/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/train.unseg'

    

    train_unseg_set = read_and_sample_file(train_unseg_set_path,1)+read_and_sample_file('/home/testcross/projects/ChatGPT/train_seg.txt',0.04)+read_and_sample_file('/home/testcross/projects/ChatGPT/ag_data.unseg',0.1)
    train_seg_set = read_and_sample_file(train_seg_set_path,1)
    
    da_set=read_and_sample_file(train_unseg_set_path,0.4)+read_and_sample_file('/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/dev.seg',0.25)+read_and_sample_file('/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/test.seg',0.25)
     

    embeddings = embedding_tool.get_embedding_for_sentences(da_set+train_unseg_set+train_seg_set)
    
    da_num = len(da_set)
    seg_num = len(train_seg_set)
    unseg_num = len(train_unseg_set)

    

    # 使用t-SNE降维到2D
    tsne = TSNE(n_components=2, random_state=42)
    X_tsne = tsne.fit_transform(embeddings)
    # 绘制结果并保存为文件
    plt.figure(figsize=(8, 6))
    
    X_p=X_tsneX_tsne[:, 0][da_num+unseg_num:seg_num+unseg_num+da_num]
    Y_p=X_tsne[:, 1][da_num+unseg_num:seg_num+unseg_num+da_num]
    
    
    plt.scatter(X_tsne[:, 0][da_num:da_num+unseg_num], X_tsne[:, 1][da_num:da_num+unseg_num], c='C0', cmap='viridis',marker='x', s=40,alpha=0.5,label='augmented data')
    plt.scatter(X_tsne[:, 0][0:da_num], X_tsne[:, 1][0:da_num], c='green', cmap='viridis',marker='x', s=40,alpha=0.5,label='pseudo-labeled data')
    plt.scatter(X_tsne[:, 0][da_num+unseg_num:seg_num+unseg_num+da_num], X_tsne[:, 1][da_num+unseg_num:seg_num+unseg_num+da_num], c='C1', cmap='viridis',marker='*', s=40,label='training data')
    plt.legend()

  

    # 保存图像到文件
    plt.savefig('tsne_output.png',dpi=600)

    # 关闭图像窗口
    plt.close()
    
if __name__ == '__main__':
   random_data()
