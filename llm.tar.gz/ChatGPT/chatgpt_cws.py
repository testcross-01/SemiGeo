from openai import OpenAI
from tqdm import tqdm
import datetime
import milvus_tool
import data_preprocessing.my_preprocessing

client = OpenAI()
results =[]
model_name = "gpt-4o"
collection_name="GeoCWS"
metric_type="COSINE"
topK=5

def construct_icl(collection_name,inputs,metric_type):
    icls=[]
    res = milvus_tool.search_all(collection_name,inputs,metric_type,topK)
    for hits in res:
        examples = '以下是几个地质中文分词的示例：\n'
        for hit in hits:
            examples+=hit.get('entity')['seg_sentence']+'\n'
        icls.append(examples)
    return icls

def da_rag_input(input,icl):
    prompt = icl + "假设你是一名地质学专家，请分析示例的句构成和词语构成方式，对下面的输入文本进行数据增强，按照分词形式进行输出。结果只需要将增强后的数据依次输出即可，只输出三个增强结果,不需要编号。"
    stream = client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user",
                   "content": prompt + "\n输入：" + input}],
        stream=True,
    )
    result = ''
    for chunk in stream:
        if chunk.choices[0].delta.content is not None:
            result += chunk.choices[0].delta.content
    return result

def cws_rag_input(input,icl):
    prompt =icl+ "假设你是一名地质学专家，请基于地质术语构词方法，对给定文本进行分词。\n请你首先判断文本的词性，然后根据文本的词性对文本进行分词。对于分词的结果请判断词语是否存在修饰关系或是存在链接符号，将修饰词或链接符号与其对应的词进行连接，组合成新的词，如'黄绿色细砂岩'、'莱阳市龙旺庄镇 - 万第镇一带'。\n请用空格进行区分中文词或标点符号以提供答案，如'中文词或标点符号1 中文词或标点符号2'\n如果没有结果，请返回如下空字符串：''。请确保每个字符都正常输出。\n输入：主要岩性为灰黄、黄绿色细砂岩、粉砂岩及页岩，底部少量砾岩，层厚约120米。\n输出：主要 岩性 为 灰黄 、 黄绿色细砂岩 、 粉砂岩 及 页岩 ， 底部 少量 砾岩 ， 层厚 约 120米 。"
    stream = client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user",
                   "content": prompt + "\n输入：" + input}],
        stream=True,
    )
    result = ''
    for chunk in stream:
        if chunk.choices[0].delta.content is not None:
            result += chunk.choices[0].delta.content

    # 解析 JSON 字符串
    # words = json.loads(result)
    #
    # 用空格连接单词
    # result = ' '.join(words)

    return result

def cws_input(input):
    prompt="假设你是一名地质学专家，请基于地质术语构词方法，对给定文本进行分词。\n请你首先判断文本的词性，然后根据文本的词性对文本进行分词。对于分词的结果请判断词语是否存在修饰关系或是存在链接符号，将修饰词或链接符号与其对应的词进行连接，组合成新的词，如'黄绿色细砂岩'、'莱阳市龙旺庄镇 - 万第镇一带'。\n请用空格进行区分中文词或标点符号以提供答案，如'中文词或标点符号1 中文词或标点符号2'\n如果没有结果，请返回如下空字符串：''。请确保每个字符都正常输出。\n输入：主要岩性为灰黄、黄绿色细砂岩、粉砂岩及页岩，底部少量砾岩，层厚约120米。\n输出：主要 岩性 为 灰黄 、 黄绿色细砂岩 、 粉砂岩 及 页岩 ， 底部 少量 砾岩 ， 层厚 约 120米 。"
    stream = client.chat.completions.create(
        model= model_name,
        # v1 直接询问
        # messages=[{"role": "user",
        #            "content": "请基于中文的构词方法，对给定文本进行分词。\n文本：" + input + "\n请用空格进行区分中文词或标点符号以提供答案：'中文词或标点符号1 中文词或标点符号2'\n如果没有结果，请返回如下空字符串：''。请确保每个字符都正常输出，不要漏字。"}],

        messages=[{"role": "user",
                   "content":prompt+"\n输入：" + input}],
        stream=True,
    )
    result = ''
    for chunk in stream:
        if chunk.choices[0].delta.content is not None:
            result+=chunk.choices[0].delta.content

    # 解析 JSON 字符串
    # words = json.loads(result)
    #
    # 用空格连接单词
    # result = ' '.join(words)

    return result

def compare_sentences(sentence1, sentence2):
    sentence1 = sentence1.replace(' ','').replace('\n','')
    sentence2 = sentence2.replace(' ','').replace('\n','')
    return len(sentence1)==len(sentence2)

def read_lines(unseg_file):
    lines = []
    with open(unseg_file, 'r', encoding='utf-8') as file:
        lines=file.readlines();
    return lines

def da_rag():
    unseg_file = '/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/train_seg.unseg'
    inputs = read_lines(unseg_file)
    
    icls=construct_icl(collection_name,inputs,metric_type)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    output_name = model_name + '_' + current_time
    file_name = output_name + '_output.txt'
    
    # 不断写入内容
    with open(file_name, 'w', encoding='utf-8') as file:
        for input,icl in tqdm(zip(inputs,icls)):
            sentence1 = input
            ag_data = da_rag_input(input,icl)
            file.write(ag_data)
    
def cws_rag():
    unseg_file = './data_preprocessing/mydata/larger/test.unseg'
    inputs = read_lines(unseg_file)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    icls=construct_icl(collection_name,inputs,metric_type)
    output_name = model_name + '_' + current_time
    file_name = output_name + '_output.txt'
    file_p_name = output_name + '_output_p.txt'
    tsv_file_name = output_name + '_output.tsv'
    # 不断写入内容
    with open(file_name, 'w', encoding='utf-8') as file:
        with open(file_p_name, 'w', encoding='utf-8') as file_p:
            for input,icl in tqdm(zip(inputs,icls)):
                sentence1 = input
                sentence2 = cws_rag_input(input,icl)
                file_p.write(sentence2 + '\n')
                if (compare_sentences(sentence1, sentence2) == True):
                    file.write(sentence2 + '\n')
                else:
                    for i in range(len(sentence1)):
                        if i != len(sentence1) - 1:
                            file.write('$ ')
                    file.write('\n')

    processor = data_preprocessing.my_preprocessing.MyPrepro()
    data = processor._process_file(file_name)
    processor._write_file(data, tsv_file_name)

def cws():
    unseg_file='./data_preprocessing/mydata/larger/test.unseg'
    inputs = read_lines(unseg_file)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    output_name = model_name+'_'+current_time
    file_name = output_name+'_output.txt'
    file_p_name = output_name + '_output_p.txt'
    tsv_file_name = output_name + '_output.tsv'
    # 不断写入内容
    with open(file_name, 'w', encoding='utf-8') as file:
        with open(file_p_name,'w',encoding='utf-8') as file_p:
            for input in tqdm(inputs):
                    sentence1 = input
                    sentence2 = cws_input(input)
                    file_p.write(sentence2+'\n')
                    if (compare_sentences(sentence1, sentence2) == True):
                        file.write(sentence2+'\n')
                    else:
                        for i in range(len(sentence1)):
                            if i != len(sentence1) - 1:
                                file.write('$ ')
                        file.write('\n')

    processor = data_preprocessing.my_preprocessing.MyPrepro()
    data = processor._process_file(file_name)
    processor._write_file(data,tsv_file_name)

if __name__ == '__main__':
    cws_rag()