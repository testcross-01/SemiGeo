import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import embedding_tool
import random


def load_words(file_path):
    """读取词表文件，每行一个词"""
    with open(file_path, 'r', encoding='utf-8') as f:
        words = [line.strip() for line in f if line.strip()]
    return words



def plot_tsne(vectors,geo_word_num,msr_word_num):
    """使用 t-SNE 进行降维并绘制散点图"""
    tsne = TSNE(n_components=2, random_state=42, perplexity=30, learning_rate=100)  # 降维到 2D
    reduced_vectors = tsne.fit_transform(vectors)

    plt.figure(figsize=(10, 8))
    plt.scatter(reduced_vectors[:, 0][0:geo_word_num], reduced_vectors[:, 1][0:geo_word_num], marker='o', color='green',label='GEO',alpha=0.5)
    plt.scatter(reduced_vectors[:, 0][geo_word_num:geo_word_num+msr_word_num], reduced_vectors[:, 1][geo_word_num:geo_word_num+msr_word_num],label='MSR',alpha=0.5, marker='o', c='C0')
    
    plt.legend(fontsize=20)  # Larger font for legend
    plt.xticks(fontsize=20)  # Larger font for x-axis ticks
    plt.yticks(fontsize=20)  # Larger font for y-axis ticks
    
    
    plt.savefig('tsne_words.png',dpi=600)

# ========== 使用示例 ==========
    
if __name__ == '__main__':
    # 1. 读取词表
    file_path = "/home/testcross/projects/ChatGPT/data_preprocessing/mydata/geo_words_clear_1.txt"  # 词表文件，每行一个词
    words = load_words(file_path)
    msr_words = load_words('/home/testcross/projects/ChatGPT/data_preprocessing/icwb2-data/gold/msr_training_words.utf8')
    
    # 计算要采样的数量（取 1/10）
    sample_size = max(1, len(msr_words) // 10)  # 至少抽取 1 个

    # 随机抽取 1/10 的数据
    msr_words = random.sample(msr_words, sample_size)
    
    # 2. 获取词向量
    vectors = embedding_tool.get_embedding_for_sentences(words+msr_words)

   

    # 3. 进行 t-SNE 降维并绘制图像
    plot_tsne(vectors,len(words),len(msr_words))
   
