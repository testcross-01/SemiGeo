from collections import defaultdict, Counter
import matplotlib.pyplot as plt
from wordcloud import WordCloud, STOPWORDS
from PIL import Image
import numpy as np
from imageio.v2 import imread

plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置黑体字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

def word_length_frequency(text, stopwords=None):
    if stopwords is None:
        stopwords = set()
    
    words = text.split()
    filtered_words = [word for word in words if word not in stopwords]
    total_words = len(filtered_words)
    
    if total_words == 0:
        return {1: 0, 2: 0, 3: 0, 4: 0,5: 0,6:0,7:0,8:0,9:0, ">=10": 0}
    
    length_counts = {1: 0, 2: 0, 3: 0, 4: 0,5: 0,6:0,7:0,8:0,9:0, ">=10": 0}
    
    for word in filtered_words:
        length = len(word)
        if length >= 10:
            length_counts[">=10"] += 1
        else:
            length_counts[length] += 1
    
    # 计算长度整体频率
    length_frequencies = {key: value / total_words for key, value in length_counts.items()}
    
    return length_frequencies
    


def generate_wordcloud(text, font_path='SIMHEI.TTF', output_file='wordcloud.png'):
    """
    生成并绘制中文词云
    :param text: 需要绘制词云的文本（字符串）
    :param font_path: 字体路径（确保支持中文）
    :param output_file: 生成的词云图片文件名
    """
   
    stopwords=load_words('./stopwords.txt')
    # 生成词云
    wordcloud = WordCloud(
        font_path=font_path,  # 指定字体，确保中文可显示
        width=800,
        height=600,
        background_color="white",
        stopwords=stopwords,
        mask=imread("./earth.jpg"),
        max_words=200,
        colormap="viridis"
    ).generate(text)
    
    

    return wordcloud

def save_wordcloud(wordcloud1,wordcloud2):
    # 创建 Matplotlib 图像窗口，并绘制两个子图
    plt.figure(figsize=(24, 13))  # 设置图像大小

    # 第一个子图（GEO 词云）
    plt.subplot(1, 2, 1)  # 1 行 2 列，第 1 个
    plt.imshow(geo_wordcloud, interpolation="bilinear")
    plt.axis("off")  # 关闭坐标轴
    plt.title("(a) GEO", y=-0.01,fontsize=30)

    # 第二个子图（MSR 词云）
    plt.subplot(1, 2, 2)  # 1 行 2 列，第 2 个
    plt.imshow(msr_wordcloud, interpolation="bilinear")
    plt.axis("off")  # 关闭坐标轴
    plt.title("(b) MSR",y=-0.01, fontsize=30)

    # 保存图像
    plt.tight_layout()  # 调整布局，防止重叠
    plt.savefig("wordcloud_comparison.png", dpi=600)  # 以高分辨率保存


def load_words(file_path):
    """从文件中读取词表"""
    with open(file_path, 'r', encoding='utf-8') as f:
        words = [line.strip() for line in f if line.strip()]
    return words
    


def read_text_file(file_path):
    """读取文本文件并返回字符串"""
    with open(file_path, "r", encoding="utf-8") as file:
        text = file.read()
   
    return text
    
def count_word_frequencies(file_path, word_list=None):
    """统计分词文件中属于词典的词的频率，并按频率降序排序"""
    word_counter = Counter()

    # 读取文件并统计符合词典的词频
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            words = line.strip().split()  # 按空格分割成单词
            if word_list != None:
                words = [word for word in words if word in word_list]  # 只保留词典中的词
            
            words = word_filter(words)
            word_counter.update(words)

    # 按照频率从高到低排序
    #sorted_words = sorted(word_counter.items(), key=lambda x: x[1], reverse=True)
    sorted_words = sorted(word_counter.items(), key=lambda x: x[1], reverse=True)
    
    return sorted_words
    
def word_filter(words):
    words = [word for word in words if len(word) >1 ]
    
    return words

def plot_word_length_frequency(freq_geo, freq_msr):
    labels = list(freq_geo.keys())
    values_geo = list(freq_geo.values())
    values_msr = list(freq_msr.values())
    
    x = range(len(labels))
    width = 0.4  # 柱状宽度
    
    plt.bar([i - width/2 for i in x], values_geo, width=width, label='GEO', color='skyblue')
    plt.bar([i + width/2 for i in x], values_msr, width=width, label='MSR', color='orange')
    
    plt.xlabel("词长度")
    plt.ylabel("频率")
    plt.title("不同长度的词频占比 (GEO vs MSR)")
    plt.xticks(ticks=x, labels=labels)
    plt.ylim(0, 1)
    plt.legend()
    plt.savefig("freq.png", dpi=600)


# 示例用法
ag_dict_path="/home/testcross/projects/ChatGPT/data_preprocessing/mydata/geo_words_clear_1.txt"
cg_dict_path="/home/testcross/projects/ChatGPT/data_preprocessing/mydata/geo_words_clear.txt"
geo_file_path = "/home/testcross/projects/ChatGPT/data_preprocessing/mydata/all_doc_1800.seg"  # 请替换为实际的分词文件路径
msr_file_path = "/home/testcross/projects/ChatGPT/data_preprocessing/icwb2-data/training/msr_training.utf8"

words = load_words(ag_dict_path)
word_frequencies = count_word_frequencies(geo_file_path)

# 输出前 100 个词
for word, freq in word_frequencies[:100]:
    print(f"{word}: {freq}")

geo_wordcloud = generate_wordcloud(read_text_file(geo_file_path))
msr_wordcloud = generate_wordcloud(read_text_file(msr_file_path))

save_wordcloud(geo_wordcloud,msr_wordcloud)

#freq_msr = {1: 0.18421729085867666, 2: 0.6454712403232578, 3: 0.08842288139075948, 4: 0.04554585810856002, '5+': 0.03634272931874607}
#freq_geo =word_length_frequency(read_text_file(geo_file_path),stopwords=load_words('./stopwords.txt'))
#plot_word_length_frequency(freq_geo, freq_msr)
#print(freq_geo)