import configparser
import time
import random


from pymilvus import MilvusClient
from pymilvus import DataType
from FlagEmbedding import BGEM3FlagModel

cfp = configparser.RawConfigParser()
cfp.read('config.ini')
milvus_uri = cfp.get('example', 'uri')
token = cfp.get('example', 'token')
milvus_client = MilvusClient(uri=milvus_uri, token=token)
print(f"Connected to DB: {milvus_uri}")

model_path = '/home/testcross/projects/models/bge-m3'
model = BGEM3FlagModel(model_path, use_fp16=False)
print('Model loaded successfully')

def search_all(collection_name,inputs,metric_type,topK):
    embeddings = model.encode(inputs, batch_size=12, max_length=8192, )['dense_vecs']
    embeddings = [embedding.tolist() for embedding in embeddings]
    np = 10

    res=[]
    for i in range(0, len(embeddings), np):
        batch = embeddings[i:i + np]
        for hits in milvus_client.search(
            collection_name=collection_name,
            anns_field="embedding",
            data=batch,
            limit=topK,
            output_fields=['seg_sentence'],
            search_params={"metric_type": metric_type,"params": {"nprobe": np}}
        ):
            res.append( hits)
    return res

def search(collection_name,input,metric_type,limit=5):

    embedding = model.encode(input, batch_size=12, max_length=8192, )['dense_vecs'].tolist()

    res = milvus_client.search(
        collection_name=collection_name,
        anns_field="embedding",
        data=[embedding],
        limit=limit,
        output_fields=['seg_sentence'],
        search_params={"metric_type":metric_type}
    )

    return res

def create_collection():
    # Check if the collection exists
    metric_type = "IP"
    collection_name = "GeoCWS_" + metric_type

    check_collection = milvus_client.has_collection(collection_name)

    if check_collection:
        milvus_client.drop_collection(collection_name)
        print("Success to drop the existing collection %s" % collection_name)

    # 设置维度
    dim = 1024

    print("Preparing schema")
    schema = milvus_client.create_schema()
    schema.add_field("id", DataType.INT64, is_primary=True, description="customized primary id")
    schema.add_field("seg_sentence", DataType.VARCHAR, max_length=1024, description="sentence")
    schema.add_field("sentence", DataType.VARCHAR, max_length=1024, description="sentence after segmentation")
    schema.add_field("embedding", DataType.FLOAT_VECTOR, dim=dim, description="sentence embedding")

    index_params = milvus_client.prepare_index_params()
    index_params.add_index("embedding", metric_type=metric_type)

    print(f"Creating example collection: {collection_name}")
    # create collection with the above schema and index parameters, and then load automatically
    milvus_client.create_collection(collection_name, dimension=dim, schema=schema, index_params=index_params)
    collection_property = milvus_client.describe_collection(collection_name)
    print("Show collection details: %s" % collection_property)

    # insert data with customized ids
    nb = 1000
    seg_sentences, sentences, embeddings = get_embedding()
    rows = []
    for i in range(len(seg_sentences)):
        rows.append(
            {"id": i, "seg_sentence": seg_sentences[i], "sentence": sentences[i], "embedding": embeddings[i].tolist()})

    milvus_client.insert(collection_name, rows)

    print(f"Inserting Succeed!")

    print("Flushing...")
    start_flush = time.time()
    milvus_client.flush(collection_name)
    end_flush = time.time()
    print(f"Flushing Succeed!")

def get_embedding_for_sentences(sentences):
    embeddings = model.encode(sentences, batch_size=12, max_length=8192, )['dense_vecs']

    return embeddings

def get_embedding():

    txt_path = '/home/testcross/projects/ChatGPT/data_preprocessing/mydata/all_doc_1800.seg'

    sentences = []
    seg_sentences = []

    with open(txt_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.replace('\n', '')
            seg_sentences.append(line)
            line = line.replace(' ', '')
            sentences.append(line)

    embeddings = model.encode(sentences, batch_size=12, max_length=8192, )['dense_vecs']

    return seg_sentences, sentences, embeddings


if __name__ == '__main__':
#    create_collection()
    print(search("GeoCWS_IP","该地层系早更新世冲洪积物堆积而成。 ","IP",10))
    print(search("GeoCWS_IP","该组为海陆交互相沉积，由冲积和海积层互相穿插叠加而成。","IP",10))