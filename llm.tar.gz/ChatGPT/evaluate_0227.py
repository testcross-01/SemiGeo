import data_preprocessing.my_preprocessing
from my_wmseg_eval import eval_sentence, cws_evaluate_word_PRF, cws_evaluate_OOV,cws_evaluate_geo
import jieba
import thulac
import pkuseg
import pyhanlp

# import pyhanlp
def read_all_labels_from_tsv(file_path):
    labels=[]
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if line:
                char, label = line.split('\t')  # 假设文字和标签是用制表符分隔的
                labels.append(label)

    return labels;


def read_sentences_from_tsv(file_path):
    sentences = []
    current_sentence = []
    labels_lists= []
    current_labels = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if line:
                if(len(line.split('\t'))==1):
                    continue;
                char, label = line.split('\t')  # 假设文字和标签是用制表符分隔的
                current_sentence.append(char)
                current_labels.append(label)
            else:
                if current_sentence:
                    sentences.append(current_sentence)
                    labels_lists.append(current_labels)
                    current_sentence = []
                    current_labels = []


    # 检查文件结束时的最后一个句子是否被添加
    if current_sentence:
        sentences.append(current_sentence)
    if current_labels:
        labels_lists.append(current_labels)
    return  sentences,labels_lists

# 读取文件的函数
def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    return lines

# 写入文件的函数
def write_file(file_path, lines):
    with open(file_path, 'w', encoding='utf-8') as file:
        for line in lines:
            file.write(line)

def test_eval():
    y_preds=['B','E','S','B','I','E']
    y_trues=['B','E','S','B','E','E']
    y_preds_list=[['B','I','I','I','I','I','E']]
    y_trues_list=[['B','I','I','I','I','I','E']]
    sentence_list=[['钙质泥质白云岩']]
    P, R, F=cws_evaluate_word_PRF(y_preds,y_trues)
    print(P, R, F)
    fgeo, rgeo, pgeo= cws_evaluate_geo(y_preds_list,y_trues_list,sentence_list)
    #print(fgeo,rgeo,pgeo)

def cws(tool='jieba'):
    unseg_file = './data_preprocessing/mydata/larger/test.unseg'
    output_file='./tmp/tmp.seg'
    pred_lables_file_path = './tmp/tmp.tsv'
    lines = read_file(unseg_file)
    segmented_lines = []
    dict=get_words()
    dict_path='./tmp/dict.txt'
    dict_lines=[]
    for word in dict:
        dict_lines.append(word+'\n')
    write_file(dict_path,dict_lines)
    if tool == 'jieba':
        for word in dict:
            jieba.add_word(word)
    if tool == 'thulac':
        thu1 = thulac.thulac(seg_only=True)
    if tool == 'pkuseg':
        seg_pku = pkuseg.pkuseg(user_dict=dict_path) 
    if tool =='hanlp':
        for word in dict:
            pyhanlp.CustomDictionary.add(word)

    for line in lines:
        # 使用jieba进行分词
        if tool == 'jieba':
            words = jieba.cut(line.strip())
        elif tool == 'thulac':
            output_thu = thu1.cut(line.strip(),text=True)
            words=output_thu.split(' ')
        elif tool == 'pkuseg':
             words = seg_pku.cut(line.strip())  
        elif tool =='hanlp':
            words =pyhanlp.HanLP.segment(line.strip())
            tmp = []
            for word in words:
                tmp.append(word.word)
            words = tmp
        # 将分词结果用空格连接成字符串
        segmented_line = ' '.join(words)
        # 添加换行符，以便逐行写入文件
        segmented_lines.append(segmented_line + '\n')
    write_file(output_file, segmented_lines)

    processor = data_preprocessing.my_preprocessing.MyPrepro()
    data = processor._process_file(output_file)
    processor._write_file(data, pred_lables_file_path)

def cws_line(text,tool='jieba'):
    unseg_file = './data_preprocessing/mydata/larger/test.unseg'
    output_file='./tmp/tmp.seg'
    pred_lables_file_path = './tmp/tmp.tsv'
    lines = read_file(unseg_file)
    segmented_lines = []
    dict=get_words()
    dict_path='./tmp/dict.txt'
    dict_lines=[]
    for word in dict:
        dict_lines.append(word+'\n')
    write_file(dict_path,dict_lines)
    if tool == 'jieba':
        for word in dict:
            jieba.add_word(word)
    if tool == 'thulac':
        thu1 = thulac.thulac(seg_only=True)
    if tool == 'pkuseg':
        seg_pku = pkuseg.pkuseg(user_dict=dict_path) 
    if tool =='hanlp':
        for word in dict:
            pyhanlp.CustomDictionary.add(word)

   
    # 使用jieba进行分词
    if tool == 'jieba':
       words = jieba.cut(text.strip())
    elif tool == 'thulac':
       output_thu = thu1.cut(text.strip(),text=True)
       words=output_thu.split(' ')
    elif tool == 'pkuseg':
       words = seg_pku.cut(text.strip())
    elif tool =='hanlp':
        words =pyhanlp.HanLP.segment(text.strip())
            
    output = ''
    for word in words:
        if tool == 'hanlp':
            output += word.word + '\\'
        else:
            output += word + '\\'
    print(output)

def get_words():
    seg_file = './tmp/train.seg'
    lines = read_file(seg_file)
    all_words = []
    for line in lines:
        # 去除行尾的换行符，并以空格为分隔符分割单词
        words = line.strip().split(' ')
        # 将分割得到的单词列表添加到all_words数组中
        all_words.extend(words)
    unique_words = set(all_words)
    all_words =list(unique_words)
    return all_words

def get_f1():
 # 调用函数并传入文件路径
    true_lables_file_path = './tmp/test.tsv'
    pred_lables_file_path = './tmp/tmp.tsv'
    cws('thulac')
    print(get_words())

    sentences,true_labels_lists =read_sentences_from_tsv(true_lables_file_path)
    sentences,pred_labels_lists =read_sentences_from_tsv(pred_lables_file_path)

    y_trues = read_all_labels_from_tsv(true_lables_file_path)
    y_preds = read_all_labels_from_tsv(pred_lables_file_path)
    P, R, F = cws_evaluate_word_PRF(y_preds,y_trues)
    fgeo_c, rgeo_c, pgeo_c = cws_evaluate_geo(pred_labels_lists,true_labels_lists,sentences)
    fgeo, rgeo, pgeo = cws_evaluate_geo(pred_labels_lists,true_labels_lists,sentences,False)


    print(f"F1-Score (F): {F:.4f}")
    print(f"F1-Score (F)-GEO: {fgeo:.4f}")
    print(f"F1-Score (F)-GEO-c: {fgeo_c:.4f}")

if __name__ == '__main__':
   get_f1()
   cws_line('岩性主要为黄绿色薄-中厚层含云母长石石英杂砂岩、灰绿色薄板状泥质粉砂岩、黄绿色厚-中厚层铁质胶结细粒砂屑石英杂砂岩，见灰色薄-中厚层生物碎屑灰岩。','thulac')
    
#chatglm
# Precision (P): 0.5031
# Recall (R): 0.4942
# F1-Score (F): 0.4986
# Precision (P)-GEO: 0.0161
# Recall (R)-GEO: 0.0295
# F1-Score (F)-GEO: 0.0111

#chatgpt gpt4-o-mini
# Precision (P): 0.6009
# Recall (R): 0.6786
# F1-Score (F): 0.6374
# Precision (P)-GEO: 0.0175
# Recall (R)-GEO: 0.0375
# F1-Score (F)-GEO: 0.0114