from FlagEmbedding import BGEM3FlagModel

model_path='/home/testcross/projects/models/bge-m3'
model = BGEM3FlagModel(model_path, use_fp16=False)

txt_path='/home/testcross/projects/WMSeg/data_preprocessing/mydata/larger/train.seg'

with open(txt_path, 'r', encoding='utf-8') as file:
    for line in file:
        line=