import configparser
import time
import random


from pymilvus import MilvusClient
from pymilvus import DataType
from FlagEmbedding import BGEM3FlagModel


model_path = '/home/testcross/projects/models/bge-m3'
model = BGEM3FlagModel(model_path, use_fp16=False)
print('Model loaded successfully')



def get_embedding_for_sentences(sentences):
    embeddings = model.encode(sentences, batch_size=12, max_length=8192, )['dense_vecs']

    return embeddings


